﻿namespace Ex_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero1 = 0, numero2 = 0;

            Console.Write("Primer número: ");
            numero1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Segon número: ");
            numero2 = Convert.ToInt32(Console.ReadLine());

            if (numero2 < numero1)
            {
                Console.WriteLine("El primer número no pot ser més gran que el segon.");
            }
            else
            {
                for (; numero1 != numero2; numero1 += 1)
                {
                    if (numero1 % 7 != 0)
                    {
                        Console.Write($"{numero1}, ");
                    }
                }
                Console.Write($"{numero1}");
            }
        }
    }
}
